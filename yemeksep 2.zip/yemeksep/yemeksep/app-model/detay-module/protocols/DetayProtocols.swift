//
//  DetayProtocols.swift
//  yemeksep
//
//  Created by MacBookPro on 19.12.2021.
//  Copyright © 2021 MacBookPro. All rights reserved.
//

import Foundation

protocol ViewToPresenterDetayProtocol {
    var yemekDetayInteractor : PresenterToInteractorDetayProtocol? {get set}
    func ekle(yemek_adi:String,yemek_resim_adi:String,yemek_fiyat:String,yemek_siparis_adet:String, kullanici_adi:String)
}
protocol PresenterToInteractorDetayProtocol {
    
    func sepeteEkle(yemek_adi:String,yemek_resim_adi:String,yemek_fiyat:String,yemek_siparis_adet:String, kullanici_adi:String)
}
protocol PresenterToRouterDetayProtocol {
    static func createModule(ref:DetayCV)
}

