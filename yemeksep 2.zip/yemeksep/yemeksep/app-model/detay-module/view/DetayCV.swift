//
//  DetayCV.swift
//  yemeksep
//
//  Created by MacBookPro on 18.12.2021.
//  Copyright © 2021 MacBookPro. All rights reserved.
//

import UIKit
import Kingfisher
class DetayCV: UIViewController {

    @IBOutlet weak var yemekImage: UIImageView!
    @IBOutlet weak var adLabael: UILabel!
    @IBOutlet weak var adetLabel: UILabel!
    @IBOutlet weak var fiyatLabel: UILabel!
    var yemek:Yemekler?
    var yemekListe = [SepetYemekler]()
    var detayPresenterNesnesi: ViewToPresenterDetayProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let y = yemek {
            if let url = URL(string: "http://kasimadalan.pe.hu/yemekler/resimler/\(y.yemek_resim_adi)"){
                DispatchQueue.main.async {
                    self.yemekImage.kf.setImage(with: url)
                }
            }
            adLabael.text = y.yemek_adi
            fiyatLabel.text = "\(y.yemek_fiyat)₺"
            navigationItem.title = y.yemek_adi
        }
        DetayRouter.createModule(ref: self)
    }
    
    @IBAction func sepeteEkle(_ sender: Any) {
        if let yadet = adetLabel.text, let y = yemek{
            detayPresenterNesnesi?.ekle(yemek_adi: y.yemek_adi, yemek_resim_adi: y.yemek_resim_adi,yemek_fiyat:y.yemek_fiyat, yemek_siparis_adet: yadet, kullanici_adi: "edasumer")
        }
        
    }
    
    @IBAction func adetStepper(_ sender: UIStepper) {
         adetLabel.text = "\(Int(sender.value))"
    }
}
