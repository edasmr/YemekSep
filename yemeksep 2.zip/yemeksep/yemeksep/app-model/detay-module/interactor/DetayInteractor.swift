//
//  DetayInteractor.swift
//  yemeksep
//
//  Created by MacBookPro on 19.12.2021.
//  Copyright © 2021 MacBookPro. All rights reserved.
//

import Foundation

import Alamofire
class DetayInteractor: PresenterToInteractorDetayProtocol {
    func sepeteEkle(yemek_adi: String, yemek_resim_adi: String,yemek_fiyat:String, yemek_siparis_adet: String, kullanici_adi: String) {
        let params:Parameters = ["yemek_adi":yemek_adi,"yemek_resim_adi":yemek_resim_adi,"yemek_fiyat":yemek_fiyat,"yemek_siparis_adet":yemek_siparis_adet,"kullanici_adi":kullanici_adi]
        Alamofire.request("http://kasimadalan.pe.hu/yemekler/sepeteYemekEkle.php", method: .post,parameters: params).responseJSON{ response in
            if let data = response.data{
                do{
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String:Any]{
                        print(json)
                    }
                }catch{
                    print(error.localizedDescription)
                }
            }
        }
    }
}

