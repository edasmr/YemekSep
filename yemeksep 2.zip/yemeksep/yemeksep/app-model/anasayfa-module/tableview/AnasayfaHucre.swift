//
//  AnasayfaHucre.swift
//  yemeksep
//
//  Created by MacBookPro on 19.12.2021.
//  Copyright © 2021 MacBookPro. All rights reserved.
//

import UIKit

class AnasayfaHucre: UITableViewCell {

    @IBOutlet weak var yemekFiyatLabel: UILabel!
    @IBOutlet weak var yemekAdLabel: UILabel!
    @IBOutlet weak var anasayfaImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
