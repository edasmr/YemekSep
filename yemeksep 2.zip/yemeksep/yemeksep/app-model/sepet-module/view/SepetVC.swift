//
//  SepetVC.swift
//  yemeksep
//
//  Created by MacBookPro on 18.12.2021.
//  Copyright © 2021 MacBookPro. All rights reserved.
//

import UIKit

class SepetVC: UIViewController {

    @IBOutlet weak var sepetTableView: UITableView!
    
    @IBOutlet weak var totalLabel: UILabel!
    
    var yemekler = [SepetYemekler]()
    var sepetPresenterNesnesi:ViewToPresenterSepetProtocol?
    var fiyat = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sepetTableView.delegate = self
        sepetTableView.dataSource = self
        SepetRouter.createModule(ref: self)

       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        sepetPresenterNesnesi?.yemekleriYukle(kullaniciadi: "edasumer")
        get_total()
    }
    
    
    func get_total(){
        var iterator = 1
        var toplam = 0
        fiyat = 0
        while iterator <= yemekler.count {
            fiyat = Int(yemekler[iterator-1].yemek_fiyat)! * Int(yemekler[iterator-1].yemek_siparis_adet)!
            toplam += fiyat
            iterator += 1
        }
        totalLabel.text = "Toplam Sepet Tutari:\(toplam)₺"
    }
}

extension SepetVC:PresenterToViewSepetProtocol{
    func vieweVeriGonder(yemeklerListesi: Array<SepetYemekler>) {
        self.yemekler = yemeklerListesi
        DispatchQueue.main.async {
            self.sepetTableView.reloadData()
            self.get_total()
        }
    }
}
extension SepetVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return yemekler.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let yemek = yemekler[indexPath.row]
        let cell = sepetTableView.dequeueReusableCell(withIdentifier: "SepetHucre") as! SepetHucre
        cell.yemekAdLabel.text = yemek.yemek_adi
        fiyat = Int(yemek.yemek_siparis_adet)! * Int(yemek.yemek_fiyat)!
        cell.fiyatLabel.text = "\(yemek.yemek_fiyat)"
        cell.adetLabel.text = "\(yemek.yemek_siparis_adet)"
        cell.totalFiyatLabel.text = "Tutar:\(fiyat)₺"
        cell.stepper.value = Double(yemek.yemek_siparis_adet)!
        if let url = URL(string: "http://kasimadalan.pe.hu/yemekler/resimler/\(yemek.yemek_resim_adi)"){
            DispatchQueue.main.async {
                cell.sepetImage.kf.setImage(with: url)
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let silAction = UIContextualAction(style: .destructive, title: "SİL"){ (UIContextualAction,view,bool) in
            let yemek = self.yemekler[indexPath.row]
            let alert = UIAlertController(title: "Silme Islemi", message: "\(yemek.yemek_adi) silinsin mi?", preferredStyle: .alert)
            let iptalAction = UIAlertAction(title: "Iptal", style: .cancel) { action in
                
            }
            alert.addAction(iptalAction)
            let evetAction = UIAlertAction(title: "Evet", style: .destructive) { action in
                self.sepetPresenterNesnesi?.sil(sepet_yemek_id: yemek.sepet_yemek_id, kullanici_adi: yemek.kullanici_adi)
            }
            alert.addAction(evetAction)
            self.present(alert, animated: true)
        }
        return UISwipeActionsConfiguration(actions: [silAction])
}

  
}
  


