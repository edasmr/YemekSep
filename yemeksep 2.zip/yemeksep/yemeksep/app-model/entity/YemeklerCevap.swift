//
//  YemeklerCevap.swift
//  yemeksep
//
//  Created by MacBookPro on 19.12.2021.
//  Copyright © 2021 MacBookPro. All rights reserved.
//

import Foundation
class YemeklerCevap: Codable {
    var yemekler: [Yemekler]?
}
